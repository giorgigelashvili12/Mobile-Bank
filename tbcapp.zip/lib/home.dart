import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: 30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.home, size: 100, color: Color(0xFF00A3E0)),
            SizedBox(height: 10),
            Text("გამარჯობა!",
                style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF004C97))),
            SizedBox(height: 20),
            Text(
              'ეს არის მარტივი მობაილ ბანკის აპლიკაცია. აქ არის მხოლოდ ვიზუალი და ლოგიკა',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, color: Colors.black87),
            ),
            SizedBox(height: 15),
            Text(
              'შესაძლებელია ბარათის დამატება, ფულის გადარიცხვა და კომუნალურების გადახდა.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
            SizedBox(height: 40),
            Divider(),
            SizedBox(height: 20),
            Row(
              children: [
                Icon(Icons.person, color: Colors.grey),
                SizedBox(width: 10),
                Text('მოსწავლე: ',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                Text('გიორგი გელაშვილი'),
              ],
            ),
            SizedBox(height: 10),
            Row(
              children: [
                Icon(Icons.school, color: Colors.grey),
                SizedBox(width: 10),
                Text('სკოლა: ', style: TextStyle(fontWeight: FontWeight.bold)),
                Expanded(child: Text('ნიკო ნიკოლაძის სახელობის სკოლა-ლიცეუმი')),
              ],
            ),
            SizedBox(height: 10),
            Row(
              children: [
                Icon(Icons.location_on, color: Colors.grey),
                SizedBox(width: 10),
                Text('რაიონი: ', style: TextStyle(fontWeight: FontWeight.bold)),
                Text('იმერეთი'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
