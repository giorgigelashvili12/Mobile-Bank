import 'package:flutter/material.dart';
import './home.dart';
import './payments.dart';
import './wallet.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TBC Bank',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HomePage(title: ''),
    );
  }
}

class HomePage extends StatefulWidget {
  final String title;
  const HomePage({super.key, required this.title});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController parolisControlleri = TextEditingController();
  final TextEditingController emailisControlleri = TextEditingController();
  final TextEditingController nameController = TextEditingController();

  String shedegi = "";

  @override
  void dispose() {
    parolisControlleri.dispose();
    emailisControlleri.dispose();
    nameController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _checkLoginStatus();
  }

  Future<void> _checkLoginStatus() async {
    final prefs = await SharedPreferences.getInstance();
    bool? loggedin = prefs.getBool('loggedin');

    if (loggedin == true) {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const Dashboard()),
        );
      }
    }
  }

  Future<void> _setLoginStatus(bool status) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('loggedin', status);
    await prefs.setString('userName', nameController.text);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Image.network(
                'https://www.greenclimate.fund/sites/default/files/styles/small/public/organisation/logo-jsctbc.png?itok=42pf4yIq',
                height: 80),
            const SizedBox(height: 40),
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Name',
                prefixIcon: Icon(Icons.person),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: emailisControlleri,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Email',
                prefixIcon: Icon(Icons.email),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: parolisControlleri,
              obscureText: true,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Password',
                prefixIcon: Icon(Icons.password),
              ),
            ),
            Padding(
                padding: const EdgeInsets.all(10.0),
                child: Text(shedegi,
                    style: const TextStyle(
                        color: Colors.red, fontWeight: FontWeight.bold))),
            const SizedBox(height: 10),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF00A3E0),
                foregroundColor: Colors.white,
                minimumSize: const Size(double.infinity, 55),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
              onPressed: () {
                setState(() {
                  if (nameController.text.isEmpty) {
                    shedegi = 'Name field is empty';
                  } else if (emailisControlleri.text.isEmpty) {
                    shedegi = "Email field is empty";
                  } else if (parolisControlleri.text.isEmpty) {
                    shedegi = "Password field is empty";
                  } else {
                    shedegi = "";
                    _setLoginStatus(true);
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const Dashboard()),
                    );
                  }
                });
              },
              child: const Text('Submit',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _Dashboard();
}

class _Dashboard extends State<Dashboard> {
  int index = 0;
  bool chans = true;

  final List<Widget> pages = [
    const Home(),
    const Payments(),
    const Wallet(),
  ];

  void dawera(int tappedIndex) {
    setState(() {
      index = tappedIndex;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            const Text("TBC Bank", style: TextStyle(color: Color(0xffffffff))),
        backgroundColor: const Color(0xFF00A3E0),
        actions: [
          IconButton(
            color: const Color(0xffffffff),
            icon: Icon(chans ? Icons.visibility : Icons.visibility_off),
            onPressed: () => setState(() => chans = !chans),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            color: const Color(0xffffffff),
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.setBool('loggedin', false);
              if (mounted) {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const HomePage(title: '')),
                );
              }
            },
          )
        ],
      ),
      body: pages[index],
      bottomNavigationBar: chans
          ? BottomNavigationBar(
              items: const [
                BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
                BottomNavigationBarItem(
                    icon: Icon(Icons.payment), label: 'Payments'),
                BottomNavigationBarItem(
                    icon: Icon(Icons.wallet), label: 'Wallet')
              ],
              currentIndex: index,
              selectedItemColor: const Color(0xFF00A3E0),
              onTap: dawera,
            )
          : null,
    );
  }
}
