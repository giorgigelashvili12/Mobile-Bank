import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: Payments()));

class Payments extends StatefulWidget {
  const Payments({super.key});

  @override
  State<Payments> createState() => PaymentS();
}

class PaymentS extends State<Payments> {
  double balance = 5000.0;
  double goal = 2450.0;
  List history = [];

  final List services = [
    {
      "name": "Electricity",
      "icon": Icons.electric_bolt,
      "color": Colors.orange
    },
    {"name": "Water", "icon": Icons.water_drop, "color": Colors.blue},
    {"name": "Gas", "icon": Icons.local_fire_department, "color": Colors.red},
    {"name": "Internet", "icon": Icons.wifi, "color": Colors.purple},
  ];

  void charge(String name, double amount, bool goalupdate) {
    if (balance >= amount) {
      setState(() {
        balance = balance - amount;
        if (goalupdate) {
          goal = goal + amount;
        }
        history.insert(0, {"name": name, "price": amount});
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Balance: ₾${balance.toStringAsFixed(0)}")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Services",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 15),
            GridView.builder(
              shrinkWrap: true,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 1.6,
                mainAxisSpacing: 10, // erti aq
                crossAxisSpacing: 10,
              ),
              itemCount: services.length,
              itemBuilder: (context, index) {
                final s = services[index];
                return InkWell(
                  onTap: () => charge(s['name'], 50, false),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.grey[100],
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(s['icon'], color: s['color'], size: 28),
                        const SizedBox(height: 5),
                        Text(s['name'],
                            style:
                                const TextStyle(fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                );
              },
            ),
            const Divider(height: 50),
            const Text("Savings Goal",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text("მარსისკენ: ₾${goal.toInt()} / 10000"),
            const SizedBox(height: 5),
            LinearProgressIndicator(value: goal / 10000),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: () => charge("Goal Deposit", 100, true),
              child: const Text("Add ₾100 to Goal"),
            ),
            const Divider(height: 50),
            const Text("History",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: history.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(history[index]['name']),
                  trailing: Text("-₾${history[index]['price']}"),
                );
              },
            ),
            const Divider(height: 30),
            Container(
              padding: const EdgeInsets.all(15),
              color: Colors.black,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text("TOTAL SPENT",
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold)),
                  Text(
                    "₾${history.fold(0.0, (prev, e) => prev + e['price'])}",
                    style: const TextStyle(
                        color: Colors.greenAccent, fontSize: 18),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ვიზუალზე gemini დავიხმარე, შეიძლება არაა იდეალური
// არ მინდოდა მთლიანად AI-ს გამოყენებით გამეკეთებინა
// მიმართულებები მომცდა და ერორები damifixa
