import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';

class Wallet extends StatefulWidget {
  const Wallet({super.key});

  @override
  State<Wallet> createState() => Walletstate();
}

class Walletstate extends State<Wallet> {
  List<Map<String, dynamic>> history = [];
  List<Map<String, dynamic>> cards = [];

  @override
  void initState() {
    super.initState();
    getcard();
  }

  Future<void> savecard() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('saved_cards', json.encode(cards));
    await prefs.setString('transaction_history', json.encode(history));
  }

  Future<void> getcard() async {
    final prefs = await SharedPreferences.getInstance();
    String? savedCards = prefs.getString('saved_cards');
    String? savedHistory = prefs.getString('transaction_history');

    setState(() {
      if (savedCards != null) {
        cards = List<Map<String, dynamic>>.from(json.decode(savedCards));
      }
      if (savedHistory != null) {
        history = List<Map<String, dynamic>>.from(json.decode(savedHistory));
      }
    });
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.redAccent,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  int? cardi;
  String? amountError;

  String bankname = "";
  String cardnum = "";

  void addcard() {
    bankname = "";
    cardnum = "";
    String? error;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) => Padding(
          padding: EdgeInsets.only(
            left: 20, right: 20, top: 20,
            bottom: MediaQuery.of(context).viewInsets.bottom +
                20, // Avoid keyboard overlap
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text("Add new card",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              TextField(
                decoration: const InputDecoration(labelText: "Bank"),
                onChanged: (value) => bankname = value,
              ),
              TextField(
                decoration: const InputDecoration(
                  labelText: "Card Number",
                  hintText: "XXXX XXXX XXXX XXXX",
                ),
                keyboardType: TextInputType.number,
                // STRATEGY: Only allow 16 digits maximum
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(16),
                ],
                onChanged: (value) => cardnum = value,
              ),
              if (error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 15),
                  child: Text(error!,
                      style: const TextStyle(
                          color: Colors.red, fontWeight: FontWeight.bold)),
                ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (bankname.trim().isEmpty || cardnum.trim().isEmpty) {
                    setModalState(() => error = "missing required fields");
                    return;
                  }
                  // VALIDATION: Must be exactly 16
                  if (cardnum.length != 16) {
                    setModalState(() => error = "must be exactly 16 numbers");
                    return;
                  }

                  setState(() {
                    cards.add({
                      "bank": bankname,
                      "number": cardnum,
                      "balance": 500.0,
                    });
                  });
                  savecard();
                  Navigator.pop(context);
                },
                child: const Text("Done"),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void transfer() {
    if (cardi == null) {
      _showError("Select a card first");
      return;
    }

    double amount = 0;
    String user = "";
    double currentBalance = cards[cardi!]['balance'];
    amountError = null;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
      builder: (context) => StatefulBuilder(builder: (context, setModalState) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom + 20,
            left: 20,
            right: 20,
            top: 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("received from ${cards[cardi!]['bank']}",
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 18)),
              const SizedBox(height: 15),
              TextField(
                decoration: const InputDecoration(labelText: "To who"),
                onChanged: (value) => user = value,
              ),
              TextField(
                decoration: InputDecoration(
                  labelText: "Amount",
                  prefixText: "₾ ",
                  errorText: amountError,
                ),
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  setModalState(() {
                    double? parsed = double.tryParse(value);
                    if (value.isEmpty) {
                      amountError = null;
                    } else if (parsed == null) {
                      amountError = "enter numbers";
                    } else if (parsed > currentBalance) {
                      amountError = "not enough (Max: ₾$currentBalance)";
                    } else {
                      amountError = null;
                      amount = parsed;
                    }
                  });
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  minimumSize: const Size(double.infinity, 50),
                ),
                onPressed: () {
                  if (user.trim().isEmpty) {
                    setModalState(
                        () => amountError = "who are u sending this to");
                    return;
                  }
                  if (amount <= 0 || amountError != null) {
                    setModalState(() => amountError = "enter an amount");
                    return;
                  }

                  setState(() {
                    cards[cardi!]['balance'] -= amount;
                    history.insert(0, {
                      "user": user,
                      "amount": amount,
                      "bank": cards[cardi!]['bank'],
                      "date": DateTime.now().toString().substring(5, 16),
                      "type": "transfer"
                    });
                  });
                  savecard();
                  Navigator.pop(context);

                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("Transferred ₾$amount to $user!")),
                  );
                },
                child: const Text("Confirm Transfer",
                    style: TextStyle(color: Colors.white)),
              ),
            ],
          ),
        );
      }),
    );
  }

  void deletecard(int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Delete Card"),
        content: Text(
            "Are you sure you want to remove your ${cards[index]['bank']} card?"),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel")),
          TextButton(
            onPressed: () {
              setState(() {
                cards.removeAt(index);
                if (cardi == index) {
                  cardi = null;
                } else if (cardi != null && cardi! > index) {
                  cardi = cardi! - 1;
                }
              });
              savecard();
              Navigator.pop(context);
            },
            child: const Text("Delete", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Row(
              children: [
                const Text('My Wallet',
                    style:
                        TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                IconButton(
                  icon: const Icon(Icons.add_circle,
                      size: 35, color: Color(0xFF00A3E0)),
                  onPressed: addcard,
                ),
              ],
            ),
            const SizedBox(height: 20),
            if (cards.isEmpty)
              const Center(child: Text("No cards yet."))
            else
              for (int i = 0; i < cards.length; i++)
                GestureDetector(
                  onTap: () => setState(() {
                    cardi = (cardi == i) ? null : i;
                  }),
                  onLongPress: () => deletecard(i),
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 15),
                    child: cardbox(
                      cards[i]['bank'],
                      cards[i]['number'],
                      cards[i]['balance'],
                      isSelected: cardi == i,
                    ),
                  ),
                ),
            const SizedBox(height: 30),
            const Text("Quick Actions",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 15),
            Row(
              children: [
                actionbtn(Icons.send, "Transfer", Colors.orange, transfer),
                const SizedBox(width: 20),
                actionbtn(Icons.payments, "Bill Pay", Colors.green, () {}),
              ],
            ),
            const SizedBox(height: 30),
            const Text("History",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            if (history.isEmpty)
              const Text("No transactions yet.",
                  style: TextStyle(color: Colors.grey))
            else
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: history.length,
                itemBuilder: (context, index) {
                  final item = history[index];
                  final isPay = item['type'] == 'payment';
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(
                      backgroundColor: isPay ? Colors.green : Colors.orange,
                      child: Icon(isPay ? Icons.receipt : Icons.send,
                          color: isPay ? Colors.green : Colors.orange,
                          size: 20),
                    ),
                    title: Text(item['user']),
                    subtitle: Text("${item['bank']} • ${item['date']}"),
                    trailing: Text("-₾${item['amount']}",
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, color: Colors.red)),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }

  Widget cardbox(String bank, String num, double balance,
      {bool isSelected = false}) {
    return Container(
      padding: const EdgeInsets.all(20),
      width: double.infinity,
      height: 200,
      decoration: BoxDecoration(
        border: isSelected ? Border.all(color: Colors.white, width: 3) : null,
        gradient: const LinearGradient(
          colors: [Color(0xFF00A3E0), Color(0xFF004C97)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(bank,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold)),
              if (isSelected)
                const Icon(Icons.check_circle, color: Colors.white)
              else
                const Icon(Icons.credit_card, color: Colors.white),
            ],
          ),
          Text("Balance: ₾${balance.toStringAsFixed(2)}",
              style: const TextStyle(color: Colors.white70, fontSize: 16)),
          Text(
            num.replaceAllMapped(
                RegExp(r".{4}"), (match) => "${match.group(0)} ").trim(),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 22,
              letterSpacing: 2,
              fontFamily: 'monospace',
            ),
          ),
        ],
      ),
    );
  }

  Widget actionbtn(
      IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
            child: Icon(icon, color: Colors.white, size: 30),
          ),
          const SizedBox(height: 8),
          Text(label,
              style:
                  const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}
